Compile in this folder using: latexmk -pdf -interaction=nonstopmode -halt-on-error paper.tex
Anonymous: latexmk -pdf -interaction=nonstopmode -halt-on-error paper_anonymous.tex
Requires pdfLaTeX, Biber and standard LaTeX packages. Three manuscript figure PDFs converted to 300 dpi JPEG, plus supplied Sensitivity graph PDF converted to JPEG. Original manuscript prose unchanged except image paths. Anonymous copy removes author block, contributions and identifying repository details.
